package com.niit.shoppingcartfrontend;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.niit.dao.SupplierDAO;
import com.niit.model.Supplier;

@Controller
public class SupplierController {
	@Autowired
	private SupplierDAO supplierDAO;
	@Autowired
	private Supplier supplier;
	
	@RequestMapping(value= "/suppliers", method= RequestMethod.GET)
	public String listSupplier(Model model)
	{
	model.addAttribute("supplier", new Supplier());
	model.addAttribute("supplierList",this.supplierDAO.list());
	return "supplier";
	}

	@RequestMapping(value="/supplier/add", method=RequestMethod.POST)
	public String addSupplier(@ModelAttribute("supplier")Supplier supplier)
	{
		supplierDAO.save(supplier);
	return "redirect:/suppliers";
	
	}
	@RequestMapping("supplier/remove/{id}")
	public ModelAndView removeSupplier(@PathVariable("id")String id)
	{
		supplier = supplierDAO.get(id);
		ModelAndView mv =new ModelAndView("supplier");
		if(supplier== null)
		{
			mv.addObject("error Mesage", "could not delete the category");
		}
		else
		{
			supplierDAO.delete(supplier);
		}
		return mv;
	}
	
	@RequestMapping("supplier/edit/{id}")
	public String editSupplier(@PathVariable("id")String id,Model model)
	{
		model.addAttribute("supplier",this.supplierDAO.get(id));
		model.addAttribute("listsupplier", this.supplierDAO.list());
		return "supplier";
	}
}
