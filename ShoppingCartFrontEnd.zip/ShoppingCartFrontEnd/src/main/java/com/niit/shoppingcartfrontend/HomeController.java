package com.niit.shoppingcartfrontend;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.niit.dao.CategoryDAO;
import com.niit.dao.UserdetailsDAO;
import com.niit.model.Category;
import com.niit.model.Userdetails;
@Controller
public class HomeController {
	
	@Autowired
	CategoryDAO categoryDAO;
	@Autowired
	Category category;
	@Autowired
	Userdetails Userdetails;
	@Autowired
	UserdetailsDAO UserdetailsDAO;
	
	
	@RequestMapping("/")
	public ModelAndView onLoad(HttpSession session)
	{
	ModelAndView mv = new ModelAndView("/home");
	session.setAttribute("category", category);
	session.setAttribute("categoryList", categoryDAO.list());

	return mv;
	}
	
	

	
@RequestMapping("/registerHere")
public ModelAndView registerhere()
{
	ModelAndView mv = new ModelAndView("/home");
	mv.addObject("userDetails", Userdetails);
	mv.addObject("isUserClickedRegisterHere", "true");
	return mv;
}

@RequestMapping("/LoginHere")
public ModelAndView loginHere()
{
	ModelAndView mv = new ModelAndView("/home");
	mv.addObject("userDetails", Userdetails);
	mv.addObject("isUserClickedLoginHere", "true");
	return mv;
}
	
@RequestMapping(value="registersucess",method = RequestMethod.POST)
public ModelAndView registerUser(@ModelAttribute Userdetails userdetails)
{
	ModelAndView mv = new ModelAndView("/home");
	if(UserdetailsDAO.get(userdetails.getId())==null)
	{
		UserdetailsDAO.save(userdetails);
		mv.addObject("successMessage","you are successfully register");
	}
	else
	{
		mv.addObject("msg", "user exist with this id");
	}
	
	mv.addObject("isUserClickedSubmit", "true");
	return mv;
}
	

}
