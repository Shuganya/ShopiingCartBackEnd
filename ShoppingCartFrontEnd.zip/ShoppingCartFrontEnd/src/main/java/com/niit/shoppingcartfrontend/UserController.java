package com.niit.shoppingcartfrontend;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.niit.dao.UserdetailsDAO;
import com.niit.model.Userdetails;

@Controller
public class UserController {

	@Autowired
	UserdetailsDAO userdetailsDAO;
	
	@Autowired
	Userdetails userdetails;
	
	@RequestMapping("/login")
	public ModelAndView login(@RequestParam(value = "id")String id, @RequestParam(value= "password")String password,HttpSession session)
	{
		ModelAndView mv = new ModelAndView("home");
		String msg;
		userdetails = userdetailsDAO.isValidUser(id, password);
		if(userdetails== null)
		{
			msg = "Invalid user...please try again";
			
		}
		else
		{
			if(userdetails.getRole().equals("ROLE_ADMIN"))
			{
				mv = new ModelAndView("adminHome");
			}
			session.setAttribute("Welcome", userdetails.getFname());
			
		}
		return mv;
	}
	
}
