package com.niit.model;

import javax.persistence.*;

import org.springframework.stereotype.Component;

@Entity
@Table(name="Product")
@Component
public class Product {
	@Id
	private String id;
	private String name;

	private int price;
	private String description;
	
	@ManyToOne
	@JoinColumn(name="category_id", updatable = false,insertable =false)
	private Category category;
	
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}

}
