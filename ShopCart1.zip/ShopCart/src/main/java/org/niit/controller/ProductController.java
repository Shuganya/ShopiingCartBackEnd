package org.niit.controller;

import org.niit.dao.CategoryDAO;
import org.niit.dao.ProductDAO;
import org.niit.dao.SupplierDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import org.niit.model.Category;
import org.niit.model.Supplier;
import org.niit.util.FileUtil;
import org.niit.model.Product;

@Controller
public class ProductController {
	@Autowired(required=true)
	private ProductDAO productDAO;

	@Autowired(required = true)
	private CategoryDAO categoryDAO;

	@Autowired(required = true)
	private SupplierDAO supplierDAO;

	private String path="E:\\images";
	@RequestMapping(value="/products",method=RequestMethod.GET)
	public String listProducts(Model model)
	{
		model.addAttribute("product", new Product());
		model.addAttribute("supplier", new Supplier());
		model.addAttribute("category",new Category());
		model.addAttribute("productList",this.productDAO.list());
		model.addAttribute("categoryList",this.categoryDAO.list());
		model.addAttribute("supplierList",this.supplierDAO.list());
		return "AdminProduct";
	}
	
	@RequestMapping(value="/addproduct", method=RequestMethod.POST)
public String addProduct(@ModelAttribute("product")Product product , Model model)
{
		Category category = categoryDAO.getByName(product.getCategory().getName());
		
		Supplier supplier = supplierDAO.getByName(product.getSupplier().getName());
		
		product.setCategory(category);
		product.setSupplier(supplier);
		
		product.setCategory_id(category.getId());
		product.setSupplier_id(supplier.getId());
		productDAO.saveOrUpdate(product);
		
		MultipartFile image = product.getImage();
		FileUtil.upload(path,image,product.getId()+".jpg");
		
		
		model.addAttribute("productList",this.productDAO.list());
		model.addAttribute("categoryList",this.categoryDAO.list());
		model.addAttribute("supplierList",this.supplierDAO.list());
		return "AdminProduct";
}
	
@RequestMapping("removeproduct/{id}")
public String removeProduct(@PathVariable("id")String id ) throws Exception
{
	productDAO.delete(id);
	return "redirect:/products";
	}
@RequestMapping("editproduct/{id}")
public String editProduct(@PathVariable("id")String id, Model model)
{
	model.addAttribute("product",this.productDAO.get(id));
	model.addAttribute("productList", this.productDAO.list());
	model.addAttribute("categoryList",this.categoryDAO.list());
	model.addAttribute("supplierList",this.supplierDAO.list());
	return "AdminProduct";
	
}
}

