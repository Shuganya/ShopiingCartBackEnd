package com.niit.model;

import javax.persistence.*;

import org.springframework.stereotype.Component;

@Entity
@Component
@Table(name="Blog")
public class Blog {

}
